/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CatalogLaavor;

/**
 *
 * @author Fernando
 * @param <T>
 */
public interface Measure<T> {
    public int Measure(T first, T second);
}

/*
public static void printOutput(NewVersionTest t, Object o, String s){
    System.out.println(t.returnAString(o, s));
}*/